print('# Fahrenheit to Celsius conversion program\n')
print('fahren = float(input(\'Enter degrees Fahrenheit: \'))')
print('celsius = (fahren - 32) * 5 / 9')
print('print(fahren, \'degrees Fahreheit equals\',\n      format(celsius, \'.1f\'), \'degrees Celsius\')')
