import random

lotto = random.sample(range(1, 46), 6)

print('Lotto numbers of the week:', lotto[0], lotto[1], lotto[2], lotto[3], lotto[4], lotto[5])
