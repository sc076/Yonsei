p. 74 q. 6
print('John Doe\n123 Main Street\nAnytown, Maryland 21009')

p.74 q. 7 
print('It's raining today')

p.75 q. 12
a) 12/6.0 = 2.0 
Dividing integer number by float which leads to result in float format
b) 21//10 = 2
// - Floor division operator which returns only digits before the comma 
c) 25//10.0
// - Floor operator which returns only the digits before the comma
but since we divide with floating number, the result is in float format  
