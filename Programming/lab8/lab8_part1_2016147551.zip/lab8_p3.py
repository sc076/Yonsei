import turtle

def drawCircle(turtle, x, y, r):
    """ Draw a circle on the screen.

        turtle is the drawing object to be used.
        x and y are the x and y coordinates of the circle's center.
        r is the radius of the circle.
        All measures are given in units of pixels.
    """

    #Assuming the turtle is setup before hand
    #in the function only the window is Initialized
    window = turtle.Screen()

    #Getting new turtle object and draws circle
    drawing = turtle.getturtle()
    drawing.penup()
    drawing.setposition(x, y)
    drawing.pendown()
    drawing.circle(r)

    #Exits on user click
    turtle.exitonclick()
