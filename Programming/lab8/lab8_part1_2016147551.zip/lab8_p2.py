#As there is no answer in YSCEC, I assume the turtle object
#is created in the body and then I Initialize the window
import turtle

def drawSquare(myturtle, x, y, a):
    """Draw a square on the screen.

        turttle is the drawing object to be used.
        x and y specify the x and y coordinates of the
        lower left corner of the square.
        a is the length of each side of the square.
        x, y, and a are given in units of pixels.
    """

    #initializing the window
    window = myturtle.Screen()
    square = myturtle.getturtle()

    #Start drawing the square with visible pointer
    square.penup()
    square.setposition(x, y)
    square.pendown()
    square.setposition(x+a, y)
    square.setposition(x+a, y+a)
    square.setposition(x, y+a)
    square.setposition(x, y)
    
    #Closes the window on user click
    myturtle.exitonclick()
