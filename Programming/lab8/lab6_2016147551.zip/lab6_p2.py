#Order alphabetically
fruits = []
weights = []

fruit_name = input('Enter a fruit type (q to quit): ')

while fruit_name != 'q':
    if fruit_name not in fruits:
        fruits.append(fruit_name)
        weight = int(input('Enter the weight in kg: '))
        weights.append(weight)
    else:
        weight = int(input('Enter the weight in kg: '))
        weights[fruits.index(fruit_name)] += weight

    fruit_name = input('Enter a fruit type (q to quit): ')

counter = 0
cpy_ls = []

for fruit in fruits:
     cpy_ls.append([fruit, weights[counter]] )
     counter += 1


#Bubble Sort
for index in range(0, len(cpy_ls)):
    for nxt in range(index+1, len(cpy_ls)):
        if cpy_ls[index]>cpy_ls[nxt]:
            temp = cpy_ls[index]
            cpy_ls[index] = cpy_ls[nxt]
            cpy_ls[nxt] = temp

for fruit in cpy_ls:
    print(fruit[0] + ', ' + str(fruit[1])+'kg.')
