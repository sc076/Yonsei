def calculate(l):
    sum = 0
    for n in range(1, l+1):
        sum += 1/n
    return sum

l = int(input('Enter the limit L: '))

counter = 1
sum = 0

while l != 0:
    sum = calculate(l)
    print('Sum of the initial', l, 'term(s): ', '{0:5f}'.format(sum))
    l = int(input('Enter the limit L: '))
