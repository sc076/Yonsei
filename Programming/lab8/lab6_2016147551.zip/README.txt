1. a) str1[3]
   b) str1.index('o')

2. a) len(lst)
   b)
  #Function returning number of the elements in list of sublists
  def count_el(lst):
    for sublst in lst:
      for el in sublst:
        cnt += 1
    return cnt

3. a) list1[0] -> 10     list2[0] = 50
   b) list1[0] -> 1      list2[0] = 1
   c) list1[0] -> 1      list2[0] = 15
   d) list1[0] -> 0      list2[0] = 5
