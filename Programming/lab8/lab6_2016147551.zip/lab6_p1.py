from collections import Counter

#Program that takes first names and counts how many times the letter A appears

names = input('Enter a name (q to quit): ')
name_list = []
counter = 0

while names != 'q':
    name_list.append(names)
    names = input('Enter a name (q to quit): ')

for name in name_list:

    for letter in name:
        if letter == 'a':
            counter += 1

print('Appearance of letter \'a\':', counter)
